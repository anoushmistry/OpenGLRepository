--Open the File TwoTriangles.cpp and run the code

-- Also check if the shader are named properly like specified in the main file (TwoTriangles.cpp)

--myfragment and myVertex are the names of the shaders